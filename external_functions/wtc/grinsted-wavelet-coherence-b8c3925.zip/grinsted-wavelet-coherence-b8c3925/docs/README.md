This folder has the jekyll source for the documentation website. http://grinsted.github.io/wavelet-coherence 

